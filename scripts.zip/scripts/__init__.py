# Omphalos hunt scripts package
